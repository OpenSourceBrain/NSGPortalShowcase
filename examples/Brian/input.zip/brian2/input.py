import brian2

print("Current version of Brian: %s"%brian2.__version__)

