#!/bin/bash -l


cd /home/padraig/neuroConstructSVN/models/Parallel/simulations/Sim1_58


export simRef="Sim1_58"
export projName="Parallel"

export remoteHost="trestles-login.sdsc.edu"
export remoteUser="pgleeson"
export simulatorLocation="/opt/neuron/powerpc64/bin/nrniv"

projDir=/home/pgleeson/Parallel_astrolabe
simDir=$projDir"/"$simRef

echo "Going to send files to dir: "$simDir" on "$remoteHost
echo "Local dir: "$PWD

echo "cd $simDir;mpirun -host  node0,node0,node0,node0,node0,node0,node0,node0 "$simulatorLocation" -mpi  "$simDir"/"$projName".hoc">runmpi.sh

chmod u+x runmpi.sh


zipFile=$simRef".tar.gz"

echo "Going to zip files into "$zipFile

tar czvf $zipFile *.mod *.hoc *.p *.g *.props *.dat *.sh *.py *.xml *.h5 *Utils

echo "Going to send to: $simDir on $remoteUser@$remoteHost"
scp $zipFile $remoteUser@$remoteHost:$simDir

ssh $remoteUser@$remoteHost "cd $simDir;tar xzf $zipFile; rm $zipFile"
# ssh $remoteUser@$remoteHost "cd $simDir;/bin/bash -ic /opt/neuron/powerpc64/bin/nrnivmodl" # Now run on compute node
ssh $remoteUser@$remoteHost "cd $simDir;/bin/bash -ic 'qsub subjob.sh'"
ssh $remoteUser@$remoteHost "echo 'Submitted job!';/bin/bash -ic 'qstat -u $remoteUser'"
rm -rf $zipFile
sleep 15


rm checkingRemote

