import sys

print("Hello from Python: %s"% sys.version)
