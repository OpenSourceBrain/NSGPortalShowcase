import brian2

print("Version: %s"%brian2.__version__)

